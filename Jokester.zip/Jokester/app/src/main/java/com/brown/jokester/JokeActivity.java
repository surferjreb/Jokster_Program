package com.brown.jokester;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class JokeActivity extends AppCompatActivity {

    Jokes[] mjoke = new Jokes[]{
            new Jokes(R.string.joke1, R.string.punchLine1),
            new Jokes(R.string.joke2, R.string.punchLine2),
            new Jokes(R.string.joke3, R.string.punchLine3),
            new Jokes(R.string.joke4, R.string.punchLine4),
            new Jokes(R.string.joke5, R.string.punchLine5)
    };
    private int[] mPrevJoke = new int[10];

    private int mCurrentIndex = 0;
    private int mPrevIndex = 0;
    private int clickCount = 0;
    private int clickCountP = 0;
    private Random rand = new Random();
    TextView mJokeView;
    Button mNextButton;
    Button mPrevButton;


    public void updateJoke(){
        int joke;

        mCurrentIndex = rand.nextInt(mjoke.length);
        joke = mjoke[mCurrentIndex].getJoke();
        mPrevJoke[mPrevIndex] = mCurrentIndex;
        mPrevIndex += 1;
        Log.i("myPrevIndex", String.valueOf(mPrevIndex));
        mJokeView.setText(joke);

    }
    public void updateJoke(int index){
        int joke;
        joke = mjoke[mPrevJoke[index]].getJoke();
        mJokeView.setText(joke);

    }

    private void tellJoke(){
        int punchLine;

            punchLine = mjoke[mCurrentIndex].getPunchLine();
            Toast.makeText(this, punchLine, Toast.LENGTH_SHORT).show();

    }

    private void tellPrevJoke(){
        int punchLine;

        punchLine = mjoke[mPrevJoke[mPrevIndex]].getPunchLine();
        Toast.makeText(this, punchLine, Toast.LENGTH_SHORT).show();
        mPrevIndex -= 1;
    }

    public void getPrevJoke(){
        int joke;

        if(mPrevIndex < 0){
            mPrevIndex = mPrevJoke.length;
            updateJoke(mPrevIndex);

        }
        else if(mPrevIndex > mPrevJoke.length){
            mPrevIndex = 0;
            updateJoke(mPrevIndex);
        }
        else{
            updateJoke(mPrevIndex);
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mJokeView = findViewById(R.id.joke_teller);
        //set text to first question array

        mNextButton = findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(clickCount == 0) {
                    tellJoke();
                    clickCount += 1;
                }
                else if(clickCount == 1) {
                    updateJoke();
                    clickCount = 0;
                }



            }
        });

        mPrevButton = findViewById(R.id.prev_button);
        mPrevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(clickCountP == 0) {
                    getPrevJoke();
                    clickCountP += 1;
                }
                else if(clickCountP == 1) {

                    tellPrevJoke();
                    clickCountP = 0;

                }


            }
        });


        updateJoke();


    }


}
