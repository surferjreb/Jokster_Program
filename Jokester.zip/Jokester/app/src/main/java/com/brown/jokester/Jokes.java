package com.brown.jokester;

public class Jokes {

    private int joke;
    private int punchLine;

    public Jokes(int joke, int punchLine){
        this.joke = joke;
        this.punchLine = punchLine;

    }//End Constructor

    public int getJoke() {
        return joke;
    }

    public void setJoke(int joke) {
        this.joke = joke;
    }

    public int getPunchLine() {
        return punchLine;
    }

    public void setPunchLine(int punchLine) {
        this.punchLine = punchLine;
    }


}
